﻿#region Using Directives

using Brandstagram.DataContracts;

#endregion

namespace Brandstagram.ServiceContracts.Responses
{
    public class GetUserResponse
    {
        public User User { get; set; }
    }
}
