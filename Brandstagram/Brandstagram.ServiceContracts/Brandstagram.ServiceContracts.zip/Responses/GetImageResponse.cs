﻿#region Using Directives

using Brandstagram.DataContracts;

#endregion

namespace Brandstagram.ServiceContracts.Responses
{
    public class GetImageResponse
    {
        public Image Image { get; set; }
    }
}
