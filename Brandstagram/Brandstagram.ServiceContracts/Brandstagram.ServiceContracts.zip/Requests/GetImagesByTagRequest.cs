﻿namespace Brandstagram.ServiceContracts.Requests
{
    public class GetImagesByTagRequest
    {
        public string Tag { get; set; }
    }
}
