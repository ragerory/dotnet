﻿namespace Brandstagram.ServiceContracts.Requests
{
    public class GetUserRequest
    {
        public int UserId { get; set; }
    }
}
