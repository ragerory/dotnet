﻿namespace Brandstagram.ServiceContracts.Requests
{
    public class GetImageRequest
    {
        public string ImageId { get; set; }
    }
}
