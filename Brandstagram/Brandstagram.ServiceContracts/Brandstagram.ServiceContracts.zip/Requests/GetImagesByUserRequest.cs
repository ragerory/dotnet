﻿namespace Brandstagram.ServiceContracts.Requests
{
    public class GetImagesByUserRequest
    {
        public string UserId { get; set; }
    }
}
