﻿namespace Brandstagram.ServiceContracts.Requests
{
    public class DeleteUserRequest
    {
        public int UserId { get; set; }
    }
}
